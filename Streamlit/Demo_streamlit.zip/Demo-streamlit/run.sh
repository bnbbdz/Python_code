streamlit run main.py
